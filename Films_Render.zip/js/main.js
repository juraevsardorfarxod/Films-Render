// function normalize date of film
function normalizeDate(evt) {
   let date=new Date(evt);
   let year=date.getFullYear();
   let month=String(date.getMonth()+1).padStart(2,0);
   let day=String(date.getDate()).padStart(2,0);
   return day+'.'+month+'.'+year;
};


// data submit to HTML
let newList=document.querySelector('.list');

function render(arr, node) {
   node.innerHTML=null;
   for(film of arr) {
      let newItem=document.createElement('li')
      newItem.setAttribute('class', 'list_item')
      
      let newPoster=document.createElement('img');
      let newTitle=document.createElement('h4');
      let newOverview=document.createElement('p');
      let newReleaseDate=document.createElement('time');
      let newGenres=document.createElement('ul');
      
      newPoster.setAttribute('src', film.poster);
      newPoster.setAttribute('class', 'poster');
      newGenres.setAttribute('class', 'list_genres');
   
      newTitle.textContent=film.title;
      newOverview.textContent=film.overview.split(' ').slice(0,10).join(' ');
      newReleaseDate.textContent=normalizeDate(film.release_date);
      for(genre of film.genres) {
         let newGenresItem=document.createElement('li');
         newGenresItem.textContent=genre; 
         newGenres.appendChild(newGenresItem);
      };
   
      newItem.appendChild(newPoster);
      newItem.appendChild(newTitle);
      newItem.appendChild(newOverview);
      newItem.appendChild(newReleaseDate);
      newItem.appendChild(newGenres);
   
      node.appendChild(newItem);
   }
}


// Select Unikal Genres of All Genres
let newForm=document.querySelector('.newForm');
let newSelect=document.querySelector('.newSelect');

function generate(films, node) {
   let selectGenre=[];
   for(film of films) {
      for(genre of film.genres) {
         if(!selectGenre.includes(genre)) {
            selectGenre.push(genre);
         }
      } 
   };

   for(genre of selectGenre) {
      let newOption=document.createElement('option');
      newOption.textContent=genre;
      newOption.setAttribute('value', genre);
      newSelect.appendChild(newOption);
   };
}


// newForm.addEventListener('change', function(evt){
//    resultGenre = evt.target.value;
// });


newForm.addEventListener('submit', function(evt) {
   evt.preventDefault();
   let resultGenre=newSelect.value;
   // console.log(resultGenre);
   let filteredFilms=[];
   if(resultGenre=='All') {
      filteredFilms=films;
   } else {
      filteredFilms=films.filter(function(film) {
         return film.genres.includes(resultGenre);
      });
   }
   render(filteredFilms, newList);
   console.log(filteredFilms);
});

render(films, newList);
generate(films, newSelect);




